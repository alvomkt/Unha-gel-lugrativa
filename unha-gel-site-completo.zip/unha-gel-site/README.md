# Unha de Gel Lucrativa - Site do Curso

## 📋 Descrição do Projeto

Este é um site completo e modular para o infoproduto "Unha de Gel Lucrativa", desenvolvido para ser entregue automaticamente via plataforma Curvano após a compra do curso.

## 🎯 Objetivo

Transformar o conteúdo do curso em uma experiência web profissional, organizada e esteticamente agradável, com:
- Design feminino e moderno
- Navegação intuitiva por módulos
- Sistema de certificado personalizado
- Responsividade para dispositivos móveis

## 🏗️ Estrutura do Projeto

```
unha-gel-site/
├── index.html                 # Página inicial com boas-vindas
├── css/
│   └── style.css             # Estilos principais (design feminino)
├── js/
│   ├── main.js               # JavaScript principal
│   └── certificate.js        # Sistema de certificados
├── images/
│   ├── covers/               # Capas dos módulos
│   │   ├── modulo1-cover.png
│   │   ├── modulo2-cover.png
│   │   ├── modulo3-cover.png
│   │   ├── modulo4-cover.png
│   │   ├── modulo5-cover.png
│   │   ├── modulo6-cover.png
│   │   └── modulo7-cover.png
│   └── certificate-bg.png    # Fundo do certificado
├── modules/
│   ├── modulo1.html          # Como Começar
│   ├── modulo2.html          # Onde Encontrar Fornecedores
│   ├── modulo3.html          # Materiais Essenciais
│   ├── modulo4.html          # Técnicas Práticas (em desenvolvimento)
│   ├── modulo5.html          # Atendimento e Precificação (em desenvolvimento)
│   ├── modulo6.html          # Marketing Básico (em desenvolvimento)
│   ├── modulo7.html          # Gestão do Negócio (em desenvolvimento)
│   └── encerramento.html     # Página final com certificado
├── generate_certificate.py   # Script Python para gerar PDF
└── README.md                 # Esta documentação
```

## 🎨 Design e Identidade Visual

### Paleta de Cores
- **Rosa Claro**: #FFB6C1
- **Lilás**: #DDA0DD  
- **Rosa Escuro**: #FF69B4
- **Nude**: #F5DEB3
- **Branco**: #FFFFFF

### Tipografia
- **Títulos**: Playfair Display (serif elegante)
- **Subtítulos**: Dancing Script (cursiva feminina)
- **Corpo**: Inter (sans-serif moderna)

### Características Visuais
- Gradientes suaves entre as cores principais
- Bordas arredondadas (border-radius)
- Sombras sutis para profundidade
- Ícones e emojis para tornar o conteúdo mais atrativo
- Layout responsivo para mobile e desktop

## 📚 Módulos do Curso

1. **Como Começar** - Introdução, mindset e planejamento inicial
2. **Onde Encontrar Fornecedores** - Melhores fornecedores e locais de compra
3. **Materiais Essenciais** - Lista completa de produtos necessários
4. **Técnicas Práticas** - Aplicação, manutenção e remoção
5. **Atendimento e Precificação** - Como calcular preços e atender clientes
6. **Marketing Básico** - Instagram, WhatsApp e boca a boca
7. **Gestão do Negócio** - Controle de agenda, estoque e finanças

## 🏆 Sistema de Certificado

### Funcionalidades
- Geração dinâmica com nome personalizado
- Design profissional com moldura decorativa
- Download como imagem PNG (via html2canvas)
- Opção de compartilhamento em redes sociais
- Armazenamento local do nome do usuário

### Tecnologias Utilizadas
- **HTML5/CSS3/JavaScript** para interface web
- **html2canvas** para conversão em imagem
- **Python + ReportLab** para geração de PDF (opcional)

## 🚀 Como Usar

### Para Desenvolvimento Local
1. Clone ou baixe os arquivos do projeto
2. Inicie um servidor HTTP local:
   ```bash
   cd unha-gel-site
   python3 -m http.server 8000
   ```
3. Acesse `http://localhost:8000` no navegador

### Para Produção (Curvano)
1. Faça upload de todos os arquivos para a plataforma
2. Configure o link de acesso para `index.html`
3. Teste todos os módulos e funcionalidades
4. Ative a entrega automática por email

## 📱 Responsividade

O site foi desenvolvido com design responsivo, adaptando-se automaticamente a:
- **Desktop** (1200px+)
- **Tablet** (768px - 1199px)
- **Mobile** (até 767px)

### Principais Adaptações Mobile
- Menu de navegação colapsível
- Cards de módulos em coluna única
- Certificado redimensionado
- Botões e textos otimizados para toque

## 🔧 Funcionalidades Técnicas

### JavaScript Principal (main.js)
- Sistema de progresso por módulos
- Armazenamento local de dados do usuário
- Notificações de sucesso/erro
- Compartilhamento em redes sociais
- Navegação suave entre seções

### Sistema de Certificado (certificate.js)
- Validação de entrada do usuário
- Geração dinâmica de HTML
- Conversão para imagem
- Download automático
- Reset e nova geração

## 📊 Métricas de Qualidade

### Performance
- ✅ Imagens otimizadas (PNG comprimido)
- ✅ CSS minificado e organizado
- ✅ JavaScript modular e eficiente
- ✅ Carregamento rápido de páginas

### Acessibilidade
- ✅ Contraste adequado de cores
- ✅ Textos legíveis em todos os tamanhos
- ✅ Navegação por teclado
- ✅ Labels apropriados em formulários

### SEO
- ✅ Títulos descritivos em todas as páginas
- ✅ Meta tags apropriadas
- ✅ Estrutura HTML semântica
- ✅ URLs amigáveis

## 🛠️ Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Estilização e responsividade
- **JavaScript ES6+** - Interatividade e funcionalidades
- **html2canvas** - Geração de imagens
- **Python + ReportLab** - Certificados em PDF
- **Google Fonts** - Tipografia profissional

## 📋 Lista de Verificação para Entrega

### Conteúdo
- [x] Página inicial com boas-vindas
- [x] 7 módulos de conteúdo estruturados
- [x] Página de encerramento com certificado
- [x] Textos revisados e formatados
- [x] Imagens de capa para todos os módulos

### Design
- [x] Paleta de cores feminina aplicada
- [x] Tipografia elegante e legível
- [x] Layout responsivo para mobile
- [x] Elementos visuais consistentes
- [x] Navegação intuitiva

### Funcionalidades
- [x] Sistema de certificado funcional
- [x] Navegação entre módulos
- [x] Armazenamento de progresso
- [x] Compartilhamento social
- [x] Download de certificado

### Testes
- [x] Teste em navegadores principais
- [x] Teste em dispositivos móveis
- [x] Validação de formulários
- [x] Verificação de links
- [x] Performance de carregamento

## 🎯 Próximos Passos

1. **Finalizar Módulos Restantes** - Completar módulos 4, 5, 6 e 7
2. **Otimização de Performance** - Comprimir imagens e minificar código
3. **Testes de Usuário** - Validar experiência com usuários reais
4. **Integração Curvano** - Configurar entrega automática
5. **Analytics** - Implementar rastreamento de uso

## 📞 Suporte

Para dúvidas ou problemas técnicos, consulte a documentação ou entre em contato com a equipe de desenvolvimento.

---

**Desenvolvido com 💖 para empoderar mulheres empreendedoras através da beleza e tecnologia.**

