# Estrutura do Site - Unha de Gel Lucrativa

## Arquitetura do Projeto

```
unha-gel-site/
├── index.html              # Página inicial
├── css/
│   ├── style.css           # Estilos principais
│   └── responsive.css      # Media queries
├── js/
│   ├── main.js            # JavaScript principal
│   └── certificate.js     # Geração de certificado
├── images/
│   ├── covers/            # Capas dos módulos
│   ├── icons/             # Ícones e elementos visuais
│   └── backgrounds/       # Imagens de fundo
├── modules/
│   ├── modulo1.html       # Como Começar
│   ├── modulo2.html       # Fornecedores
│   ├── modulo3.html       # Materiais Essenciais
│   ├── modulo4.html       # Técnicas Práticas
│   ├── modulo5.html       # Atendimento e Precificação
│   ├── modulo6.html       # Marketing Básico
│   ├── modulo7.html       # Gestão do Negócio
│   └── encerramento.html  # Módulo final + certificado
└── assets/
    ├── downloads/         # Arquivos para download
    └── templates/         # Templates de certificado
```

## Paleta de Cores
- Rosa claro: #FFB6C1
- Nude: #F5DEB3
- Branco: #FFFFFF
- Lilás: #DDA0DD
- Rosa escuro (acentos): #FF69B4
- Cinza suave: #F8F8F8

## Tipografia
- Títulos: 'Playfair Display' (elegante)
- Corpo do texto: 'Inter' (legível)
- Acentos: 'Dancing Script' (feminino)

## Componentes Principais
1. Header com navegação
2. Cards de módulos
3. Conteúdo estruturado
4. Botões de navegação
5. Sistema de certificado
6. Footer informativo

