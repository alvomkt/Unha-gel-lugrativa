#!/usr/bin/env python3
"""
Script para gerar certificado de conclusão do curso "Unha de Gel Lucrativa" em PDF
"""

from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import inch
from reportlab.lib.colors import Color, pink, purple, white, black
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics import renderPDF
from datetime import datetime
import sys
import os

def create_certificate(student_name, output_path="certificado.pdf"):
    """
    Cria um certificado personalizado em PDF
    
    Args:
        student_name (str): Nome do estudante
        output_path (str): Caminho do arquivo de saída
    """
    
    # Configurações da página
    page_width, page_height = landscape(A4)
    
    # Cores personalizadas
    rosa_claro = Color(1, 0.714, 0.757)  # #FFB6C1
    lilas = Color(0.867, 0.627, 0.867)   # #DDA0DD
    rosa_escuro = Color(1, 0.412, 0.706) # #FF69B4
    nude = Color(0.961, 0.871, 0.702)    # #F5DEB3
    
    # Criar o documento
    doc = SimpleDocTemplate(
        output_path,
        pagesize=landscape(A4),
        rightMargin=0.5*inch,
        leftMargin=0.5*inch,
        topMargin=0.5*inch,
        bottomMargin=0.5*inch
    )
    
    # Estilos
    styles = getSampleStyleSheet()
    
    # Estilo para título principal
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=36,
        spaceAfter=20,
        alignment=TA_CENTER,
        textColor=rosa_escuro,
        fontName='Helvetica-Bold'
    )
    
    # Estilo para subtítulo
    subtitle_style = ParagraphStyle(
        'CustomSubtitle',
        parent=styles['Normal'],
        fontSize=18,
        spaceAfter=15,
        alignment=TA_CENTER,
        textColor=black,
        fontName='Helvetica'
    )
    
    # Estilo para nome do estudante
    name_style = ParagraphStyle(
        'StudentName',
        parent=styles['Normal'],
        fontSize=32,
        spaceAfter=20,
        alignment=TA_CENTER,
        textColor=lilas,
        fontName='Helvetica-BoldOblique'
    )
    
    # Estilo para nome do curso
    course_style = ParagraphStyle(
        'CourseName',
        parent=styles['Normal'],
        fontSize=24,
        spaceAfter=15,
        alignment=TA_CENTER,
        textColor=rosa_escuro,
        fontName='Helvetica-Bold'
    )
    
    # Estilo para texto normal
    normal_style = ParagraphStyle(
        'CustomNormal',
        parent=styles['Normal'],
        fontSize=14,
        spaceAfter=10,
        alignment=TA_CENTER,
        textColor=black,
        fontName='Helvetica'
    )
    
    # Estilo para rodapé
    footer_style = ParagraphStyle(
        'Footer',
        parent=styles['Normal'],
        fontSize=12,
        alignment=TA_CENTER,
        textColor=black,
        fontName='Helvetica'
    )
    
    # Conteúdo do certificado
    story = []
    
    # Espaçamento inicial
    story.append(Spacer(1, 0.5*inch))
    
    # Título principal
    story.append(Paragraph("CERTIFICADO DE CONCLUSÃO", title_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Texto de certificação
    story.append(Paragraph("Certificamos que", subtitle_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Nome do estudante
    story.append(Paragraph(student_name, name_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Texto de conclusão
    story.append(Paragraph("concluiu com êxito o curso", subtitle_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Nome do curso
    story.append(Paragraph("UNHA DE GEL LUCRATIVA", course_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Carga horária
    story.append(Paragraph("com carga horária estimada de <b>20 horas</b>", normal_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Data atual
    current_date = datetime.now().strftime("%d de %B de %Y")
    months_pt = {
        'January': 'janeiro', 'February': 'fevereiro', 'March': 'março',
        'April': 'abril', 'May': 'maio', 'June': 'junho',
        'July': 'julho', 'August': 'agosto', 'September': 'setembro',
        'October': 'outubro', 'November': 'novembro', 'December': 'dezembro'
    }
    
    for eng, pt in months_pt.items():
        current_date = current_date.replace(eng, pt)
    
    # Informações de emissão
    story.append(Paragraph(f"Emitido em: {current_date}", normal_style))
    story.append(Paragraph("Local: Brasil", normal_style))
    story.append(Spacer(1, 0.3*inch))
    
    # Assinatura
    story.append(Paragraph("_" * 40, footer_style))
    story.append(Paragraph("<b>Alvo Marketing</b>", footer_style))
    story.append(Paragraph("Coordenação do Curso", footer_style))
    
    # Função para desenhar bordas e decorações
    def draw_decorations(canvas, doc):
        # Desenhar borda decorativa
        canvas.setStrokeColor(rosa_claro)
        canvas.setLineWidth(3)
        canvas.rect(0.3*inch, 0.3*inch, page_width-0.6*inch, page_height-0.6*inch)
        
        # Borda interna
        canvas.setStrokeColor(lilas)
        canvas.setLineWidth(1)
        canvas.rect(0.4*inch, 0.4*inch, page_width-0.8*inch, page_height-0.8*inch)
        
        # Decorações nos cantos
        canvas.setFillColor(rosa_claro)
        # Canto superior esquerdo
        canvas.circle(0.7*inch, page_height-0.7*inch, 0.1*inch, fill=1)
        # Canto superior direito
        canvas.circle(page_width-0.7*inch, page_height-0.7*inch, 0.1*inch, fill=1)
        # Canto inferior esquerdo
        canvas.circle(0.7*inch, 0.7*inch, 0.1*inch, fill=1)
        # Canto inferior direito
        canvas.circle(page_width-0.7*inch, 0.7*inch, 0.1*inch, fill=1)
    
    # Construir o PDF
    doc.build(story, onFirstPage=draw_decorations)
    
    return output_path

def main():
    """Função principal para uso via linha de comando"""
    if len(sys.argv) != 2:
        print("Uso: python generate_certificate.py 'Nome do Estudante'")
        sys.exit(1)
    
    student_name = sys.argv[1]
    output_file = f"certificado_{student_name.replace(' ', '_').lower()}.pdf"
    
    try:
        created_file = create_certificate(student_name, output_file)
        print(f"Certificado criado com sucesso: {created_file}")
    except Exception as e:
        print(f"Erro ao criar certificado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

