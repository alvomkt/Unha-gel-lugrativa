// JavaScript para geração de certificado

// Função para gerar certificado
function generateCertificate() {
    const userName = document.getElementById('userName').value.trim();
    
    if (!userName) {
        alert('Por favor, digite seu nome para gerar o certificado.');
        return;
    }
    
    // Salvar nome do usuário
    UnhaGelApp.saveUserName(userName);
    
    // Mostrar certificado
    displayCertificate(userName);
    
    // Mostrar notificação de sucesso
    UnhaGelApp.showNotification('Certificado gerado com sucesso! 🎉', 'success');
}

// Função para exibir o certificado
function displayCertificate(userName) {
    const certificateContainer = document.getElementById('certificateContainer');
    const currentDate = new Date().toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    certificateContainer.innerHTML = `
        <div id="certificate" style="
            background: url('images/certificate-bg.png') center/cover;
            width: 800px;
            height: 600px;
            margin: 0 auto;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 60px;
            box-sizing: border-box;
            border: 3px solid #FFB6C1;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        ">
            <div style="background: rgba(255,255,255,0.95); padding: 40px; border-radius: 15px; width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: center;">
                <h1 style="
                    font-family: 'Playfair Display', serif;
                    font-size: 2.5rem;
                    color: #FF69B4;
                    margin-bottom: 20px;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
                ">CERTIFICADO DE CONCLUSÃO</h1>
                
                <div style="margin: 30px 0;">
                    <p style="
                        font-family: 'Inter', sans-serif;
                        font-size: 1.2rem;
                        color: #333;
                        margin-bottom: 20px;
                        line-height: 1.6;
                    ">Certificamos que</p>
                    
                    <h2 style="
                        font-family: 'Dancing Script', cursive;
                        font-size: 3rem;
                        color: #DDA0DD;
                        margin: 20px 0;
                        text-decoration: underline;
                        text-decoration-color: #FFB6C1;
                    ">${userName}</h2>
                    
                    <p style="
                        font-family: 'Inter', sans-serif;
                        font-size: 1.1rem;
                        color: #333;
                        line-height: 1.8;
                        margin: 20px 0;
                    ">concluiu com êxito o curso</p>
                    
                    <h3 style="
                        font-family: 'Playfair Display', serif;
                        font-size: 2rem;
                        color: #FF69B4;
                        margin: 20px 0;
                    ">UNHA DE GEL LUCRATIVA</h3>
                    
                    <p style="
                        font-family: 'Inter', sans-serif;
                        font-size: 1rem;
                        color: #666;
                        margin: 20px 0;
                    ">com carga horária estimada de <strong>20 horas</strong></p>
                </div>
                
                <div style="
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 40px;
                    width: 100%;
                ">
                    <div style="text-align: left;">
                        <p style="
                            font-family: 'Inter', sans-serif;
                            font-size: 0.9rem;
                            color: #666;
                            margin: 0;
                        ">Emitido em: ${currentDate}</p>
                        <p style="
                            font-family: 'Inter', sans-serif;
                            font-size: 0.9rem;
                            color: #666;
                            margin: 5px 0 0 0;
                        ">Local: Brasil</p>
                    </div>
                    
                    <div style="text-align: right;">
                        <div style="
                            border-top: 2px solid #FFB6C1;
                            padding-top: 10px;
                            min-width: 200px;
                        ">
                            <p style="
                                font-family: 'Dancing Script', cursive;
                                font-size: 1.5rem;
                                color: #FF69B4;
                                margin: 0;
                            ">Alvo Marketing</p>
                            <p style="
                                font-family: 'Inter', sans-serif;
                                font-size: 0.8rem;
                                color: #666;
                                margin: 5px 0 0 0;
                            ">Coordenação do Curso</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Mostrar container do certificado
    certificateContainer.style.display = 'block';
    
    // Scroll para o certificado
    certificateContainer.scrollIntoView({ behavior: 'smooth' });
}

// Função para baixar certificado como imagem
function downloadCertificate() {
    const certificate = document.getElementById('certificate');
    
    if (!certificate) {
        alert('Gere o certificado primeiro!');
        return;
    }
    
    // Usar html2canvas para converter em imagem
    if (typeof html2canvas !== 'undefined') {
        html2canvas(certificate, {
            scale: 2,
            backgroundColor: '#ffffff',
            width: 800,
            height: 600
        }).then(canvas => {
            // Criar link de download
            const link = document.createElement('a');
            link.download = 'certificado-unha-gel-lucrativa.png';
            link.href = canvas.toDataURL();
            link.click();
            
            UnhaGelApp.showNotification('Certificado baixado com sucesso! 📥', 'success');
        }).catch(error => {
            console.error('Erro ao gerar certificado:', error);
            alert('Erro ao baixar certificado. Tente fazer um print da tela.');
        });
    } else {
        // Fallback: instruir usuário a fazer screenshot
        alert('Para salvar seu certificado, faça um print da tela (Ctrl+Shift+S no Windows ou Cmd+Shift+4 no Mac)');
    }
}

// Função para compartilhar certificado
function shareCertificate() {
    const userName = UnhaGelApp.getUserName();
    
    if (!userName) {
        alert('Gere o certificado primeiro!');
        return;
    }
    
    const shareText = `🎉 Acabei de concluir o curso "Unha de Gel Lucrativa"! 
    
Agora estou pronta para transformar essa habilidade em uma fonte de renda incrível! 💅✨

#UnhaDeGelLucrativa #Empreendedorismo #Beleza #NovaCarreira`;
    
    UnhaGelApp.shareContent(
        'Certificado - Unha de Gel Lucrativa',
        shareText,
        window.location.href
    );
}

// Função para resetar e gerar novo certificado
function resetCertificate() {
    document.getElementById('userName').value = '';
    document.getElementById('certificateContainer').style.display = 'none';
    document.getElementById('userName').focus();
}

// Inicialização quando a página carrega
document.addEventListener('DOMContentLoaded', function() {
    // Pré-preencher com nome salvo se existir
    const savedName = UnhaGelApp.getUserName();
    if (savedName) {
        const nameInput = document.getElementById('userName');
        if (nameInput) {
            nameInput.value = savedName;
        }
    }
    
    // Adicionar event listeners
    const generateBtn = document.getElementById('generateBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateCertificate);
    }
    
    const downloadBtn = document.getElementById('downloadBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', downloadCertificate);
    }
    
    const shareBtn = document.getElementById('shareBtn');
    if (shareBtn) {
        shareBtn.addEventListener('click', shareCertificate);
    }
    
    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', resetCertificate);
    }
    
    // Enter para gerar certificado
    const nameInput = document.getElementById('userName');
    if (nameInput) {
        nameInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                generateCertificate();
            }
        });
    }
});

// Exportar funções para uso global
window.CertificateApp = {
    generateCertificate,
    downloadCertificate,
    shareCertificate,
    resetCertificate
};

