// JavaScript principal para o site Unha de Gel Lucrativa

document.addEventListener('DOMContentLoaded', function() {
    // Inicialização
    initializeApp();
    setupNavigation();
    setupAnimations();
    setupProgressTracking();
});

// Inicialização da aplicação
function initializeApp() {
    console.log('Site Unha de Gel Lucrativa carregado com sucesso!');
    
    // Verificar se há progresso salvo
    loadUserProgress();
    
    // Configurar tema
    setupTheme();
}

// Configuração da navegação
function setupNavigation() {
    // Navegação suave entre seções
    const navLinks = document.querySelectorAll('a[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Navegação entre módulos
    const moduleLinks = document.querySelectorAll('.module-link');
    moduleLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const moduleId = this.getAttribute('data-module');
            if (moduleId) {
                markModuleAsVisited(moduleId);
            }
        });
    });
}

// Configuração de animações
function setupAnimations() {
    // Intersection Observer para animações de entrada
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
            }
        });
    }, observerOptions);

    // Observar elementos que devem ser animados
    const animatedElements = document.querySelectorAll('.module-card, .content-section');
    animatedElements.forEach(el => observer.observe(el));
}

// Sistema de progresso do usuário
function setupProgressTracking() {
    // Carregar progresso salvo
    const savedProgress = localStorage.getItem('unhaGelProgress');
    if (savedProgress) {
        const progress = JSON.parse(savedProgress);
        updateProgressIndicators(progress);
    }
}

function markModuleAsVisited(moduleId) {
    let progress = JSON.parse(localStorage.getItem('unhaGelProgress') || '{}');
    progress[moduleId] = {
        visited: true,
        visitedAt: new Date().toISOString()
    };
    localStorage.setItem('unhaGelProgress', JSON.stringify(progress));
    updateProgressIndicators(progress);
}

function updateProgressIndicators(progress) {
    const moduleCards = document.querySelectorAll('.module-card');
    moduleCards.forEach(card => {
        const moduleId = card.getAttribute('data-module');
        if (progress[moduleId] && progress[moduleId].visited) {
            card.classList.add('completed');
            
            // Adicionar indicador de conclusão
            if (!card.querySelector('.completion-badge')) {
                const badge = document.createElement('div');
                badge.className = 'completion-badge';
                badge.innerHTML = '✓ Concluído';
                card.appendChild(badge);
            }
        }
    });
}

function loadUserProgress() {
    const progress = JSON.parse(localStorage.getItem('unhaGelProgress') || '{}');
    const totalModules = 7;
    const completedModules = Object.keys(progress).length;
    
    if (completedModules > 0) {
        console.log(`Progresso: ${completedModules}/${totalModules} módulos visitados`);
    }
}

// Configuração do tema
function setupTheme() {
    // Verificar preferência de tema salva
    const savedTheme = localStorage.getItem('unhaGelTheme');
    if (savedTheme) {
        document.body.setAttribute('data-theme', savedTheme);
    }
}

// Utilitários
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remover após 3 segundos
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Função para scroll suave para o topo
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Adicionar botão de voltar ao topo
function addBackToTopButton() {
    const button = document.createElement('button');
    button.className = 'back-to-top';
    button.innerHTML = '↑';
    button.setAttribute('aria-label', 'Voltar ao topo');
    button.onclick = scrollToTop;
    
    document.body.appendChild(button);
    
    // Mostrar/esconder baseado no scroll
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            button.classList.add('visible');
        } else {
            button.classList.remove('visible');
        }
    });
}

// Inicializar botão de voltar ao topo
document.addEventListener('DOMContentLoaded', addBackToTopButton);

// Função para validar formulários (se houver)
function validateForm(formElement) {
    const requiredFields = formElement.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });
    
    return isValid;
}

// Função para copiar texto para clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showNotification('Texto copiado para a área de transferência!', 'success');
    }).catch(function(err) {
        console.error('Erro ao copiar texto: ', err);
        showNotification('Erro ao copiar texto', 'error');
    });
}

// Função para compartilhar (se suportado pelo navegador)
function shareContent(title, text, url) {
    if (navigator.share) {
        navigator.share({
            title: title,
            text: text,
            url: url
        }).then(() => {
            console.log('Conteúdo compartilhado com sucesso');
        }).catch((error) => {
            console.log('Erro ao compartilhar:', error);
        });
    } else {
        // Fallback para navegadores que não suportam Web Share API
        copyToClipboard(url);
    }
}

// Função para salvar nome do usuário
function saveUserName(name) {
    localStorage.setItem('unhaGelUserName', name);
    updateUserGreeting(name);
}

function getUserName() {
    return localStorage.getItem('unhaGelUserName') || '';
}

function updateUserGreeting(name) {
    const greetingElements = document.querySelectorAll('.user-greeting');
    greetingElements.forEach(element => {
        if (name) {
            element.textContent = `Olá, ${name}!`;
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    });
}

// Inicializar saudação do usuário
document.addEventListener('DOMContentLoaded', function() {
    const userName = getUserName();
    if (userName) {
        updateUserGreeting(userName);
    }
});

// Função para resetar progresso (para desenvolvimento/teste)
function resetProgress() {
    if (confirm('Tem certeza que deseja resetar todo o progresso?')) {
        localStorage.removeItem('unhaGelProgress');
        localStorage.removeItem('unhaGelUserName');
        location.reload();
    }
}

// Exportar funções para uso global
window.UnhaGelApp = {
    markModuleAsVisited,
    showNotification,
    saveUserName,
    getUserName,
    resetProgress,
    shareContent,
    copyToClipboard
};

